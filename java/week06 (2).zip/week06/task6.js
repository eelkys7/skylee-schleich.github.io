class calculator{
    constructor(previousoperandtexrelement){
        this.previousoperandtexrelement = previousoperandtexrelement
        this.currentoperandtextelement = currentoperandtextelement
        }
    
    clear(){
        this.currentoperand = " "
        this.previousoperand =""
        this.operation = undefined
    }
    delete(){

    }
   appendNumber(number){
    this.currentoperand = Number

    }
    chooseOperation(operation){

    }
compute(){

}

updateDisplay(){
    this.currentoperandtexrelementinnertext = this.currentoperand

}
}
const  numberButtons = document.querySelectorAll('[data-number]')
const operationButtons = document.querySelectorAll('[data-operation]')
const equalsButtons = document.querySelector('[data-equals]')
const deleteButtons = document.querySelector('[data-delete]')
const allclearButtons = document.querySelector('[data-all-clear]')
const previousoperandtexrelement = document.querySelector('[data-previous-operand]')
const currentoperandtexrelement = document.querySelector('[data-previous-operand]')

let calculator = new calculator(this.previousoperandtexrelement,this.currentoperandtextelement)
numberButtons.array.forEach(button => {
    button.addEventListener("click", () => {
        calculator.appendNumber(button.innertext)
    })
    
});